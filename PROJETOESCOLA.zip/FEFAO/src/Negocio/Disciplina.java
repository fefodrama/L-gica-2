package Negocio;

public class Disciplina {
	//PROPRIEDADE DA CLASSE
	
	private String nome = "";
	
	//M�TODOS CONSTRUTORES DA CLASSE
	
	public Disciplina() { 
	}
	
	public Disciplina(String nome){
		this.nome = nome;
	}
	
	//M�TODOS GETSET DA CLASSE
	
	public String getNome(){
		return nome;
	}
	
	public void setNome(String nome){
		this.nome = nome;
	}
	
}
