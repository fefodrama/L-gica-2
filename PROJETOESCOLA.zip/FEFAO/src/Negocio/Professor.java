package Negocio;

public class Professor {
	//PROPRIEDADE DA CLASSE
	
	private String nome = "";
	private double salario = 0;
	
	//M�TODOS CONSTRUTORES DA CLASSE
	
	public Professor() { 
	}
	
	public Professor(String nome, double salario){
		this.nome = nome;
		this.salario = salario;
	}

	
	//M�TODOS GETSET DA CLASSE
	
	public String getNome(){
		return nome;
	}
	
	public void setNome(String nome){
		this.nome = nome;
	}
	
	public double getSalario() {
		return salario;
	}
	
	public void setSal�rio(double salario) {
		this.salario = salario;
	}
}