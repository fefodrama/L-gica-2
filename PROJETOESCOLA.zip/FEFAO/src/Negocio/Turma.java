package Negocio;

	public class Turma {
		
		//PROPRIEDADES DA CLASSE
		
		private Disciplina objDisciplina = null;
		private Professor objProfessor = null;
		private Aluno[] cole��oAlunos = new Aluno[50];
		private int Indice = 0;
	
		//M�TODOS CONSTRUTORES DA CLASSE
		
		public Turma() { 
		}
		
		public Turma(Disciplina objDisciplina, Professor objProfessor) {
			this.objDisciplina = objDisciplina;
			this.objProfessor = objProfessor;
		}
		
		//M�TODOS GETSET DA CLASSE
		
		public Disciplina getObjDisciplina() {
			return objDisciplina;
		}
		
		public void setObjDisciplina ( Disciplina objDisciplina) {
			this.objDisciplina = objDisciplina;
		}
		
		public Professor getObjProfessor() {
			return objProfessor;
		}
		
		public void setProfessor (Professor objProfessor) {
			this.objProfessor = objProfessor;
		}
		
		public void AdicionarAlunoTurma (Aluno ObjAluno) {
			if (Indice < 50) {
				cole��oAlunos[Indice] = ObjAluno;
				Indice++;
			}
		}
			
		public void MostrarAlunosdaTurma() {
			for (int i = 0; i < Indice; i++) {
				System.out.println(cole��oAlunos[i].getMatricula() + " " + cole��oAlunos[i].getNome());
			}
		}
			
		}
