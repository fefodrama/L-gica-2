package Negocio;

public class Aluno {
	//PROPRIEDADE DA CLASSE
	
	private String nome = "";
	private int matricula = 0;
	
	//M�TODOS CONSTRUTORES DA CLASSE
	
	public Aluno() { 
	}
	
	public Aluno(String nome, int matricula){
		this.nome = nome;
		this.matricula = matricula;
	}

	//M�TODOS GETSET DA CLASSE
	
	public String getNome(){
		return nome;
	}
	
	public void setNome(String nome){
		this.nome = nome;
	}
	
	public double getMatricula() {
		return matricula;
		
	}
	public void setSal�rio(int matricula) {
		this.matricula = matricula;
	}
}