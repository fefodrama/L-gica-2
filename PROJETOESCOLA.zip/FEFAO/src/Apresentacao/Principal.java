package Apresentacao;

import Negocio.Aluno;
import Negocio.Disciplina;
import Negocio.Professor;
import Negocio.Turma;

public class Principal {
	public static void main (String args[]){
		
		//INSTANCIA��O DE OBJ COM CONSTRUTOR CHEIO
		Disciplina objDisciplina = new Disciplina("Linguagem de Programa��o");
				
		//INSTANCIA��O DE OBJ COM CONSTRUTOR VAZIO
		Professor objProfessor = new Professor();
		objProfessor.setNome("Professor: Luxa");
		objProfessor.setSal�rio(954);
		
		//INSTANCIA��O COM CONSTRUTOR CHEIO
		
		Turma objTurma = new Turma(objDisciplina, objProfessor);
		objTurma.AdicionarAlunoTurma(new Aluno ("Neymar", 1));
		objTurma.AdicionarAlunoTurma(new Aluno ("Messi", 2));
		objTurma.AdicionarAlunoTurma(new Aluno ("CR7", 3));

		//SA�DA DE DADOS
		
		System.out.println(objTurma.getObjDisciplina().getNome());
		System.out.println(objTurma.getObjProfessor().getNome());
		objTurma.MostrarAlunosdaTurma();
	}
}
